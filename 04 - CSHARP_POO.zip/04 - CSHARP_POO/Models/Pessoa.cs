namespace _04___CSHARP_POO.Models
{
    public class Pessoa
    {
        // definir os atributos

        public string nome;
        public string sobrenome;
        public string telefone;
        public string idade;
    }
}