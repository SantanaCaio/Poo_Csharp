﻿using System;

namespace _04___CSHARP_POO
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
